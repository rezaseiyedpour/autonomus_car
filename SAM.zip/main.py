import cv2
import numpy as np
from ultralytics import YOLO
import torch
import math
import time

# ==================== Raspberry Pi Camera (Picamera2) ====================
from picamera2 import Picamera2
from libcamera import Transform

# ==================== مسیرها ====================
model_path = "YOLO8\yolov8n-seg.pt"
# video_path حذف شد چون ورودی از دوربین می‌آید

# ==================== تنظیمات و حافظه ====================
DISPLAY_SCALE = 0.9

prev_boxes_x = [None, None, None]  # چپ، وسط، راست
ALPHA_BOX = 0.25
MAX_JUMP = 80

# آستانه مساحت مانع
CHANGE_LANE_THRESHOLD = 800

original_lane = None
lane_changed = False

# تایید مانع در چند فریم پیاپی
obstacle_frame_count = 0
OBSTACLE_CONFIRMATION_FRAMES = 5

# هیستوگرام/نوار نمونه‌برداری از ماسک لاین (بدون Hough/Canny)
BAND_HALF_HEIGHT = 14
MIN_LANE_PIXELS_IN_BAND = 350

# گیت برای قفل شدن چپ/راست روی خطوط خودشان
GATE_MIN_WIDTH = 120
GATE_WIDTH_RATIO = 0.22


# ==================== توابع کمکی ====================
def draw_square(img, center, size=14, color=(0, 255, 255)):
    x, y = center
    cv2.rectangle(img, (x - size, y - size), (x + size, y + size), color, 2)


def smooth(prev, new):
    if prev is None:
        return new
    if abs(new - prev) > MAX_JUMP:
        return prev
    return int(ALPHA_BOX * new + (1 - ALPHA_BOX) * prev)


def angle_between_vertical(p1, p2):
    dx = p2[0] - p1[0]
    dy = p2[1] - p1[1]
    angle_deg = math.degrees(math.atan2(dx, dy))
    return max(-90, min(90, angle_deg))


def detect_orange_obstacles(frame):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    lower_orange1 = np.array([0, 100, 100])
    upper_orange1 = np.array([15, 255, 255])
    lower_orange2 = np.array([165, 100, 100])
    upper_orange2 = np.array([180, 255, 255])

    mask1 = cv2.inRange(hsv, lower_orange1, upper_orange1)
    mask2 = cv2.inRange(hsv, lower_orange2, upper_orange2)
    orange_mask = cv2.bitwise_or(mask1, mask2)

    kernel = np.ones((5, 5), np.uint8)
    orange_mask = cv2.morphologyEx(orange_mask, cv2.MORPH_CLOSE, kernel)
    orange_mask = cv2.morphologyEx(orange_mask, cv2.MORPH_OPEN, kernel)
    return orange_mask


def find_largest_obstacle(mask):
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None, 0, None

    largest_contour = max(contours, key=cv2.contourArea)
    area = cv2.contourArea(largest_contour)

    M = cv2.moments(largest_contour)
    if M["m00"] == 0:
        return largest_contour, area, None
    cx = int(M["m10"] / M["m00"])
    cy = int(M["m01"] / M["m00"])
    return largest_contour, area, (cx, cy)


def is_obstacle_in_lane(cx, cy, lane, car_x, h):
    if cy < h * 0.5:
        return False

    if lane == "راست":
        return cx > car_x + 50 and abs(cx - car_x) < 300
    elif lane == "چپ":
        return cx < car_x - 50 and abs(cx - car_x) < 300
    return False


def _peak_x_in_gate_from_band(band_bin, x_left, x_right, min_col_sum=2):
    x_left = max(0, int(x_left))
    x_right = min(band_bin.shape[1], int(x_right))
    if x_right <= x_left + 5:
        return None

    col_sum = band_bin[:, x_left:x_right].sum(axis=0)
    m = int(col_sum.max()) if col_sum.size else 0
    if m < min_col_sum:
        return None

    idx = np.where(col_sum >= max(m - 1, 1))[0]
    if idx.size == 0:
        return None

    x_local = int(np.mean(idx))
    return x_left + x_local


def get_left_right_positions_gated(stable_lane_mask_u8, y_ref, prev_boxes, w):
    y1 = max(0, y_ref - BAND_HALF_HEIGHT)
    y2 = min(stable_lane_mask_u8.shape[0], y_ref + BAND_HALF_HEIGHT)
    band = stable_lane_mask_u8[y1:y2, :]
    band_bin = (band > 0).astype(np.uint8)

    lane_pixels = int(band_bin.sum())
    if lane_pixels < MIN_LANE_PIXELS_IN_BAND and (prev_boxes[0] is None or prev_boxes[2] is None):
        return None, lane_pixels

    gate_w = max(GATE_MIN_WIDTH, int(w * GATE_WIDTH_RATIO))

    if prev_boxes[0] is None or prev_boxes[2] is None:
        col_sum_full = band_bin.sum(axis=0).astype(np.float32)
        if int(col_sum_full.max()) < 2:
            return None, lane_pixels

        hist_bins = 60
        hist, _ = np.histogram(
            np.repeat(np.arange(w), col_sum_full.astype(int)),
            bins=hist_bins,
            range=(0, w)
        )

        top = np.argsort(hist)[-6:]
        xs = [int((p + 0.5) * (w / hist_bins)) for p in top]
        xs = sorted(xs)
        return (xs[0], xs[-1]), lane_pixels

    xL_prev = prev_boxes[0]
    xR_prev = prev_boxes[2]

    xL = _peak_x_in_gate_from_band(band_bin, xL_prev - gate_w, xL_prev + gate_w)
    xR = _peak_x_in_gate_from_band(band_bin, xR_prev - gate_w, xR_prev + gate_w)

    if xL is None:
        xL = xL_prev
    if xR is None:
        xR = xR_prev
    if xL > xR:
        xL, xR = xR, xL

    return (int(xL), int(xR)), lane_pixels


def print_terminal_table(angle, lane, lane_changed_flag, obstacle_detected, obstacle_in_lane, obstacle_confirmed, should_change_lane):
    angle_str = "---.--" if angle is None else f"{angle:+.2f}"

    if lane not in ["چپ", "راست", "نامشخص"]:
        lane_disp = "نامشخص    "
    elif lane == "چپ":
        lane_disp = "چپ        "
    elif lane == "راست":
        lane_disp = "راست      "
    else:
        lane_disp = "نامشخص    "

    obstacle_disp = "Yes" if obstacle_detected else "No"
    inlane_disp = "Yes" if obstacle_in_lane else "No"
    conf_disp = "Yes" if obstacle_confirmed else "No"
    change_disp = "YES" if should_change_lane else "NO"

    print("┌───────────────────────────────────────────────────────────────┐")
    print(f"│ Angle: {angle_str:>7}° │ Lane: {lane_disp}│ Lane_Changed: {str(lane_changed_flag):<5} │")
    print(f"│ Obstacle: {obstacle_disp:<3} │ InLane: {inlane_disp:<3} │ Confirmed: {conf_disp:<3} │ ChangeLane: {change_disp:<3} │")
    print("└───────────────────────────────────────────────────────────────┘")


# ==================== init ====================
print("[INFO] Loading model...")
model = YOLO(model_path)

device = "cuda" if torch.cuda.is_available() else "cpu"
model.to(device)
print(f"[INFO] Model loaded on {device}")

# ==================== Init Picamera2 ====================
print("[INFO] Initializing Picamera2...")
camera = Picamera2()

# اگر تصویر شما برعکس/چرخیده است این خط را فعال کن:
# transform = Transform(hflip=True, vflip=True)  # 180 درجه (معمولا)
transform = None

config = camera.create_preview_configuration(
    main={"size": (640, 480)},
    transform=transform
)
camera.configure(config)
camera.start()
time.sleep(0.2)
print("[INFO] Camera started.")

prev_road_mask, prev_lane_mask = None, None
alpha_road, alpha_lane = 0.8, 0.6

# FPS meter
t0 = time.time()
frame_i = 0

try:
    while True:
        # ---------------- Read from camera ----------------
        frame = camera.capture_array()  # RGB
        frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)  # to BGR for OpenCV/YOLO

        frame_i += 1
        h, w = frame.shape[:2]
        original_for_lanes = frame.copy()

        # ---------------- YOLO ----------------
        results = model.predict(frame, conf=0.15, imgsz=640, device=device, verbose=False)
        current_road_mask = np.zeros((h, w), dtype=np.uint8)

        if results[0].masks is not None:
            for mask in results[0].masks.data:
                mask_np = mask.cpu().numpy()
                mask_resized = cv2.resize(mask_np, (w, h))
                current_road_mask |= (mask_resized > 0).astype(np.uint8) * 255

        # ---------------- Road Memory ----------------
        if np.any(current_road_mask):
            if prev_road_mask is not None:
                road_mask = cv2.addWeighted(current_road_mask, alpha_road, prev_road_mask, 1 - alpha_road, 0)
            else:
                road_mask = current_road_mask
            prev_road_mask = road_mask.copy()
        else:
            road_mask = prev_road_mask if prev_road_mask is not None else current_road_mask

        # ---------------- Lane Mask ----------------
        road_only = cv2.bitwise_and(original_for_lanes, original_for_lanes, mask=road_mask.astype(np.uint8))
        gray = cv2.cvtColor(road_only, cv2.COLOR_BGR2GRAY)
        _, lane_mask = cv2.threshold(gray, 155, 255, cv2.THRESH_BINARY)
        lane_mask = cv2.morphologyEx(lane_mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        lane_mask = cv2.morphologyEx(lane_mask, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))

        if np.any(lane_mask):
            if prev_lane_mask is not None:
                stable_lane_mask = cv2.addWeighted(lane_mask, alpha_lane, prev_lane_mask, 1 - alpha_lane, 0)
            else:
                stable_lane_mask = lane_mask
            prev_lane_mask = stable_lane_mask.copy()
        else:
            stable_lane_mask = prev_lane_mask if prev_lane_mask is not None else lane_mask

        # ---------------- Visualization ----------------
        final_overlay = original_for_lanes.copy()
        final_overlay[road_mask > 127] = [255, 150, 0]
        final_img = cv2.addWeighted(original_for_lanes, 0.7, final_overlay, 0.3, 0)
        final_img[stable_lane_mask > 100] = [0, 0, 255]

        # ==================== وضعیت‌های پیش‌فرض ====================
        lane = "نامشخص"
        target_lane = "نامشخص"
        angle = None
        should_change_lane = False

        obstacle_detected_now = False
        obstacle_in_our_lane = False
        obstacle_confirmed = False
        obstacle_area = 0
        obstacle_center = None

        # ==================== Lane points ====================
        car_x = w // 2
        car_point = (car_x, h)
        vertical_ref = (car_x, int(h * 0.6))
        y_ref = int(h * 0.72)

        stable_lane_mask_u8 = stable_lane_mask.astype(np.uint8)
        lr, _ = get_left_right_positions_gated(stable_lane_mask_u8, y_ref, prev_boxes_x, w)

        # ==================== Obstacle detection ====================
        orange_mask = detect_orange_obstacles(original_for_lanes)
        contour, obstacle_area, obstacle_center = find_largest_obstacle(orange_mask)

        obstacle_detected_now = obstacle_area >= CHANGE_LANE_THRESHOLD

        if contour is not None and obstacle_center is not None:
            cx, cy = obstacle_center
            cv2.drawContours(final_img, [contour], -1, (0, 255, 0), 2)
            cv2.circle(final_img, (cx, cy), 6, (255, 0, 0), -1)
            cv2.putText(final_img, f"Area: {int(obstacle_area)}", (cx - 60, cy - 15),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2)

        if lr is not None:
            xL_raw, xR_raw = lr
            xL = smooth(prev_boxes_x[0], xL_raw)
            xR = smooth(prev_boxes_x[2], xR_raw)
            if xL > xR:
                xL, xR = xR, xL

            xC_mid = (xL + xR) // 2
            xC = smooth(prev_boxes_x[1], xC_mid)

            xs_sorted = sorted([xL, xC, xR])
            xL, xC, xR = xs_sorted[0], xs_sorted[1], xs_sorted[2]
            prev_boxes_x = [xL, xC, xR]

            for i, x in enumerate([xL, xC, xR]):
                draw_square(final_img, (x, y_ref), color=[(255, 0, 0), (0, 255, 255), (0, 255, 0)][i])

            # تشخیص لاین فعلی
            left_count = sum(1 for x in [xL, xC, xR] if x < car_x)
            right_count = sum(1 for x in [xL, xC, xR] if x > car_x)

            if left_count == 2 and right_count == 1:
                lane = "راست"
            elif right_count == 2 and left_count == 1:
                lane = "چپ"
            else:
                lane = "نامشخص"

            if original_lane is None and lane != "نامشخص":
                original_lane = lane

            # مانع در لاین ما؟
            if obstacle_center is not None:
                cx, cy = obstacle_center
                obstacle_in_our_lane = is_obstacle_in_lane(cx, cy, lane, car_x, h)

            # تایید چندفریمی (فقط وقتی مانع هم بزرگ و هم در لاین ما باشد)
            if obstacle_detected_now and obstacle_in_our_lane:
                obstacle_frame_count += 1
            else:
                obstacle_frame_count = max(0, obstacle_frame_count - 1)

            obstacle_confirmed = obstacle_frame_count >= OBSTACLE_CONFIRMATION_FRAMES
            should_change_lane = bool(obstacle_confirmed and obstacle_in_our_lane)

            # تصمیم فرمان
            if should_change_lane:
                if lane == "چپ":
                    steer_x = (xC + xR) // 2
                    target_lane = "راست"
                    lane_changed = True
                elif lane == "راست":
                    steer_x = (xL + xC) // 2
                    target_lane = "چپ"
                    lane_changed = True
                else:
                    steer_x = (xL + xR) // 2
                    target_lane = "نامشخص"
                    lane_changed = True
            else:
                if lane_changed:
                    # بازگشت
                    if original_lane == "راست":
                        steer_x = (xC + xR) // 2
                        target_lane = "راست"
                    elif original_lane == "چپ":
                        steer_x = (xL + xC) // 2
                        target_lane = "چپ"
                    else:
                        steer_x = (xL + xR) // 2
                        target_lane = lane
                    lane_changed = False
                    obstacle_frame_count = 0
                else:
                    # عادی
                    if lane == "راست":
                        steer_x = (xC + xR) // 2
                        target_lane = "راست"
                    elif lane == "چپ":
                        steer_x = (xL + xC) // 2
                        target_lane = "چپ"
                    else:
                        steer_x = (xL + xR) // 2
                        target_lane = "نامشخص"

            steer_point = (int(steer_x), y_ref)
            angle = angle_between_vertical(car_point, steer_point)

            # رسم فلش/مرجع
            arrow_color = (0, 0, 255) if should_change_lane else ((0, 255, 255) if lane_changed else (0, 255, 0))
            cv2.arrowedLine(final_img, car_point, steer_point, arrow_color, 3)
            cv2.line(final_img, car_point, vertical_ref, (255, 255, 255), 2)

        # ==================== نمایش متن‌ها روی تصویر ====================
        cv2.putText(final_img, f"Lane: {lane}", (40, 50),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 255), 2)

        if angle is not None:
            cv2.putText(final_img, f"Angle: {angle:+.1f} deg", (40, 90),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 2)
        else:
            cv2.putText(final_img, "Angle: ---", (40, 90),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 2)

        obs_text = "Obstacle: YES" if obstacle_detected_now else "Obstacle: NO"
        obs_color = (0, 0, 255) if obstacle_detected_now else (0, 255, 0)
        cv2.putText(final_img, obs_text, (40, 130),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, obs_color, 2)

        cv2.putText(final_img, f"Area: {int(obstacle_area)}  Frames: {obstacle_frame_count}/{OBSTACLE_CONFIRMATION_FRAMES}", (40, 165),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2)

        change_text = "ChangeLane: YES" if should_change_lane else "ChangeLane: NO"
        change_color = (0, 0, 255) if should_change_lane else (0, 255, 0)
        cv2.putText(final_img, change_text, (40, 200),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, change_color, 2)

        if obstacle_in_our_lane and obstacle_detected_now:
            cv2.putText(final_img, "Obstacle in our lane", (40, 235),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 0, 255), 2)

        if original_lane:
            cv2.putText(final_img, f"Original: {original_lane}", (w - 260, 50),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (200, 200, 200), 2)

        # ==================== چاپ ترمینال ====================
        print_terminal_table(
            angle=angle,
            lane=lane,
            lane_changed_flag=lane_changed,
            obstacle_detected=obstacle_detected_now,
            obstacle_in_lane=obstacle_in_our_lane,
            obstacle_confirmed=obstacle_confirmed,
            should_change_lane=should_change_lane
        )

        # FPS هر 30 فریم
        if frame_i % 30 == 0:
            dt = time.time() - t0
            fps = frame_i / dt if dt > 0 else 0
            print(f"[INFO] running... approx FPS={fps:.2f}")

        # نمایش
        display_frame = cv2.resize(final_img, None, fx=DISPLAY_SCALE, fy=DISPLAY_SCALE)
        cv2.imshow("YOLO + Lane + Orange Obstacle (Combined)", display_frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            break
        elif key == ord("r"):
            original_lane = None
            lane_changed = False
            obstacle_frame_count = 0
            prev_boxes_x = [None, None, None]
            prev_road_mask, prev_lane_mask = None, None
            print("\n" + "=" * 60)
            print("سیستم ریست شد")
            print("=" * 60)

finally:
    camera.stop()
    cv2.destroyAllWindows()
    print("[INFO] Camera stopped. Exit.")